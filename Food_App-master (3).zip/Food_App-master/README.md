Project được tạo bởi Android Studio 4.1.1.

Project đã được test và tương thích với các bản Android Studio mới hơn (tính đến bản Android Studio 2020.3).

Khi mở project lần đầu bằng Android Stuido, cần chờ một thời gian để Android Studio build Gradle.

Nếu gặp lỗi "gradle project sync failed", hãy xóa 2 folder .gradle và .idea trong thư mục của project và mở lại bằng Android Studio.

Các thiết bị đã được thử nghiệm:
- Máy ảo: Pixel 5 - Android 11.0 - API: 30
- Máy thật:
+ Vivo Y55 - Android 6.0 - API: 23
+ Vsmart Live -Android 10.0 - API: 29
